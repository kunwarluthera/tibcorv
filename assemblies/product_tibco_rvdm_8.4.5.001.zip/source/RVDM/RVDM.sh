#! /bin/sh

if [ -z "$JAVACMD" ] ; then
  if [ -n "$JAVA_HOME"  ] ; then
    echo "JAVA_HOME is set."
    if [ -x "$JAVA_HOME/jre/sh/java" ] ; then
      JAVACMD="$JAVA_HOME/jre/sh/java"
    else
      JAVACMD="$JAVA_HOME/bin/java"
    fi
  else
    echo "JAVA_HOME is not set."
    JAVACMD=java
  fi
fi

if [ "$JAVACMD" != "java" ] ; then
  if [ ! -x "$JAVACMD" ] ; then
    echo "Invalid Java executable. Exiting..."
    exit 1
  fi
else
  if [ `$JAVACMD -version >> /dev/null 2>&1` ] ; then
    echo "Invalid Java executable. Exiting..."
    exit 1
  fi
fi

if [ -z "$TIBRV_HOME" ] ; then
  echo "TIBRV_HOME is not set."
  echo "Assuming your environment has been Rendezvous-enabled explicitly..."
else
  echo "TIBRV_HOME is set."
  PATH=$TIBRV_HOME/bin:$PATH
  LD_LIBRARY_PATH=$TIBRV_HOME/lib:$LD_LIBRARY_PATH
fi

echo "Please wait, RVDM is starting..."

"$JAVACMD" -jar RVDM.jar "$@"

